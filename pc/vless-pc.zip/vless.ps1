﻿# Запуск VLESS через Xray: берёт ключ vless:// из буфера обмена, делает config.json
# и включает системный прокси Windows. Запуск: start.bat, выключение: stop.bat.
param(
    [string]$Link,
    [switch]$Stop,
    # Только проверить ключ (сделать config.json и xray -test), VPN не включать
    [switch]$CheckOnly
)
$ErrorActionPreference = 'Stop'

$Dir = $PSScriptRoot
$Xray = Join-Path $Dir 'xray.exe'
$ConfigPath = Join-Path $Dir 'config.json'
$LastKeyPath = Join-Path $Dir 'last_key.txt'
# Не 10808/10809, чтобы не мешать v2rayN/sing-box, если они тоже установлены
$SocksPort = 10820
$HttpPort = 10821
$RegPath = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings'
$ProxyBypass = '<local>;localhost;127.*;10.*;192.168.*;' + ((16..31 | ForEach-Object { "172.$_.*" }) -join ';')

function Coalesce($Value, $Default) {
    if ($Value) { $Value } else { $Default }
}

function Set-SystemProxy([bool]$On) {
    if ($On) {
        Set-ItemProperty $RegPath ProxyServer "127.0.0.1:$HttpPort"
        Set-ItemProperty $RegPath ProxyOverride $ProxyBypass
        Set-ItemProperty $RegPath ProxyEnable 1
    } else {
        Set-ItemProperty $RegPath ProxyEnable 0
    }
    # Сообщаем Windows, что настройки прокси поменялись
    if (-not ('VlessPc.Inet' -as [type])) {
        Add-Type -Namespace VlessPc -Name Inet -MemberDefinition '[DllImport("wininet.dll")] public static extern bool InternetSetOption(IntPtr h, int o, IntPtr b, int l);'
    }
    [VlessPc.Inet]::InternetSetOption([IntPtr]::Zero, 39, [IntPtr]::Zero, 0) | Out-Null
    [VlessPc.Inet]::InternetSetOption([IntPtr]::Zero, 37, [IntPtr]::Zero, 0) | Out-Null
}

function Stop-Xray {
    Get-Process xray -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $Xray } | Stop-Process -Force
}

function Get-VlessLink {
    if ($Link) { return $Link.Trim() }
    try { $clip = Get-Clipboard -Raw } catch { $clip = $null }
    if ($clip -and $clip -match 'vless://\S+') {
        Write-Host 'Ключ взят из буфера обмена.'
        return $Matches[0]
    }
    if (Test-Path $LastKeyPath) {
        $last = (Get-Content $LastKeyPath -Raw).Trim()
        if ($last.StartsWith('vless://')) {
            $answer = Read-Host 'В буфере нет ключа. Enter — использовать прошлый ключ, или вставь новый'
            if (-not $answer) { return $last }
            return $answer.Trim()
        }
    }
    return (Read-Host 'Вставь ключ vless:// (правой кнопкой мыши) и нажми Enter').Trim()
}

function ConvertFrom-VlessLink([string]$Url) {
    if ($Url -notmatch '^vless://([^@]+)@(\[[^\]]+\]|[^:/?#]+):(\d+)/?(\?[^#]*)?(#.*)?$') {
        throw 'Это не похоже на ключ vless://'
    }
    $id = [Uri]::UnescapeDataString($Matches[1])
    $address = $Matches[2].Trim('[', ']')
    $port = [int]$Matches[3]
    $query = $Matches[4]
    $name = if ($Matches[5]) { [Uri]::UnescapeDataString($Matches[5].Substring(1)) } else { $address }

    $q = @{}
    if ($query) {
        foreach ($pair in $query.TrimStart('?').Split('&')) {
            if (-not $pair) { continue }
            $kv = $pair.Split('=', 2)
            $q[$kv[0]] = if ($kv.Count -gt 1) { [Uri]::UnescapeDataString($kv[1]) } else { '' }
        }
    }

    $network = Coalesce $q.type 'tcp'
    if ($network -eq 'splithttp') { $network = 'xhttp' }
    if ($network -eq 'raw') { $network = 'tcp' }
    $security = Coalesce $q.security 'none'
    $hostHeader = Coalesce $q.host ''
    $path = Coalesce $q.path '/'
    $sni = Coalesce $q.sni (Coalesce $hostHeader $address)
    $fingerprint = Coalesce $q.fp 'chrome'

    $user = [ordered]@{ id = $id; encryption = (Coalesce $q.encryption 'none') }
    if ($q.flow) { $user.flow = $q.flow }

    $stream = [ordered]@{ network = $network; security = $security }
    switch ($security) {
        'tls' {
            $tls = [ordered]@{ serverName = $sni; fingerprint = $fingerprint }
            if ($q.alpn) { $tls.alpn = @($q.alpn.Split(',')) }
            # allowInsecure не переносим: новый Xray его убрал и не запускается с ним
            $stream.tlsSettings = $tls
        }
        'reality' {
            $stream.realitySettings = [ordered]@{
                serverName  = $sni
                fingerprint = $fingerprint
                publicKey   = $q.pbk
                shortId     = (Coalesce $q.sid '')
                spiderX     = (Coalesce $q.spx '')
            }
        }
    }
    switch ($network) {
        'ws' {
            $stream.wsSettings = [ordered]@{ path = $path; host = $hostHeader }
        }
        'httpupgrade' {
            $stream.httpupgradeSettings = [ordered]@{ path = $path; host = $hostHeader }
        }
        'xhttp' {
            $xhttp = [ordered]@{ path = $path; host = $hostHeader; mode = (Coalesce $q.mode 'auto') }
            if ($q.extra) { $xhttp.extra = $q.extra | ConvertFrom-Json }
            $stream.xhttpSettings = $xhttp
        }
        'grpc' {
            $grpc = [ordered]@{ serviceName = (Coalesce $q.serviceName ''); multiMode = ($q.mode -eq 'multi') }
            if ($q.authority) { $grpc.authority = $q.authority }
            $stream.grpcSettings = $grpc
        }
        'tcp' {
            if ($q.headerType -eq 'http') {
                $stream.tcpSettings = @{ header = [ordered]@{
                    type    = 'http'
                    request = @{ path = @($path); headers = @{ Host = @($hostHeader) } }
                } }
            }
        }
    }

    $sniffing = [ordered]@{ enabled = $true; destOverride = @('http', 'tls') }
    $config = [ordered]@{
        log       = @{ loglevel = 'warning' }
        inbounds  = @(
            [ordered]@{ tag = 'socks'; listen = '127.0.0.1'; port = $SocksPort; protocol = 'socks'; settings = @{ udp = $true }; sniffing = $sniffing },
            [ordered]@{ tag = 'http'; listen = '127.0.0.1'; port = $HttpPort; protocol = 'http'; sniffing = $sniffing }
        )
        outbounds = @(
            [ordered]@{
                tag            = 'proxy'
                protocol       = 'vless'
                settings       = @{ vnext = @([ordered]@{ address = $address; port = $port; users = @($user) }) }
                streamSettings = $stream
            },
            @{ tag = 'direct'; protocol = 'freedom' }
        )
    }
    return @{ Name = $name; Json = ($config | ConvertTo-Json -Depth 20) }
}

try {
    if ($Stop) {
        Stop-Xray
        Set-SystemProxy $false
        Write-Host 'VPN выключен, прокси Windows отключён.' -ForegroundColor Green
        return
    }
    if (-not (Test-Path $Xray)) { throw "Не найден xray.exe рядом со скриптом ($Dir)" }

    $url = Get-VlessLink
    $result = ConvertFrom-VlessLink $url
    [IO.File]::WriteAllText($ConfigPath, $result.Json, (New-Object Text.UTF8Encoding $false))
    [IO.File]::WriteAllText($LastKeyPath, $url, (New-Object Text.UTF8Encoding $false))

    $test = & $Xray run -test -c $ConfigPath 2>&1
    if ($LASTEXITCODE -ne 0) {
        $test | Write-Host
        throw 'Xray не принял этот ключ. Возьми другой ключ в боте.'
    }
    if ($CheckOnly) {
        Write-Host "OK: $($result.Name)"
        return
    }

    Stop-Xray
    Set-SystemProxy $true
    Write-Host ''
    Write-Host "VPN включён: $($result.Name)" -ForegroundColor Green
    Write-Host 'Не закрывай это окно. Чтобы выключить — нажми Ctrl+C или запусти stop.bat.'
    Write-Host "Для программ без системного прокси: SOCKS5 127.0.0.1:$SocksPort, HTTP 127.0.0.1:$HttpPort"
    Write-Host ''
    try {
        & $Xray run -c $ConfigPath
    } finally {
        Set-SystemProxy $false
        Write-Host 'VPN выключен, прокси Windows отключён.' -ForegroundColor Yellow
    }
} catch {
    Write-Host "Ошибка: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
