@echo off
chcp 65001 >nul
title VLESS VPN
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0vless.ps1"
pause
